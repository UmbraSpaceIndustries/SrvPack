DELETE OLD VERSIONS BEFORE INSTALLING THIS MOD!

To use alternate textures, replace PodEngine.png and PodCapsule.png with the png's in the altTextures folder.  Do NOT delete the normal maps!

