To use alternate textures, replace PodEngine.tga and PodCapsule.tga with the png's in the altTextures folder.  You will need to delete the TGAs - do NOT delete the normal maps!
